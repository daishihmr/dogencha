enchant();
$(function() {
	var game = new Game(320, 320);
	game.preload("test.l3p.js");
	game.onload = function() {
		var scene = new Scene3D();

		var test = game.assets["test.l3p.js"];
		test.rotateYaw(Math.PI);
		test.rotatePitch(-0.5);
		scene.addChild(test);
		
		game.addEventListener("enterframe", function() {
			if (game.input.up) {
				test.rotatePitch(0.1);
			}
			if (game.input.down) {
				test.rotatePitch(-0.1);
			}
			if (game.input.left) {
				test.rotateHead(-0.1);
			}
			if (game.input.right) {
				test.rotateHead(0.1);
			}
		});
	}
	game.start();
});